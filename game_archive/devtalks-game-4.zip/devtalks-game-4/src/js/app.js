import $ from "jquery";
import game from "./game.js";
import leaderboard from "./leaderboard.js";

game.init();
leaderboard.init();
